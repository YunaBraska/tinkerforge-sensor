# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/data_logger/ui/device_dialog.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_DeviceDialog(object):
    def setupUi(self, DeviceDialog):
        DeviceDialog.setObjectName("DeviceDialog")
        DeviceDialog.setWindowModality(QtCore.Qt.WindowModal)
        DeviceDialog.resize(435, 471)
        self.verticalLayout = QtWidgets.QVBoxLayout(DeviceDialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.btn_add_device = QtWidgets.QPushButton(DeviceDialog)
        self.btn_add_device.setObjectName("btn_add_device")
        self.gridLayout.addWidget(self.btn_add_device, 0, 0, 1, 1)
        self.tree_widget = QtWidgets.QTreeWidget(DeviceDialog)
        self.tree_widget.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.tree_widget.setObjectName("tree_widget")
        self.tree_widget.headerItem().setText(0, "1")
        self.tree_widget.header().setVisible(False)
        self.gridLayout.addWidget(self.tree_widget, 1, 0, 1, 4)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 2, 1, 1)
        self.btn_close = QtWidgets.QPushButton(DeviceDialog)
        self.btn_close.setObjectName("btn_close")
        self.gridLayout.addWidget(self.btn_close, 0, 3, 1, 1)
        self.btn_refresh = QtWidgets.QPushButton(DeviceDialog)
        self.btn_refresh.setObjectName("btn_refresh")
        self.gridLayout.addWidget(self.btn_refresh, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(DeviceDialog)
        QtCore.QMetaObject.connectSlotsByName(DeviceDialog)
        DeviceDialog.setTabOrder(self.btn_add_device, self.btn_refresh)
        DeviceDialog.setTabOrder(self.btn_refresh, self.btn_close)
        DeviceDialog.setTabOrder(self.btn_close, self.tree_widget)

    def retranslateUi(self, DeviceDialog):
        _translate = QtCore.QCoreApplication.translate
        DeviceDialog.setWindowTitle(_translate("DeviceDialog", "Add Device"))
        self.btn_add_device.setText(_translate("DeviceDialog", "Add Device"))
        self.btn_close.setText(_translate("DeviceDialog", "Close"))
        self.btn_refresh.setText(_translate("DeviceDialog", "Refresh"))

