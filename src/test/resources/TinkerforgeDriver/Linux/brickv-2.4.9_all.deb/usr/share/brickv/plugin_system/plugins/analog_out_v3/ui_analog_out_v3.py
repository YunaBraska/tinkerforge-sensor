# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/analog_out_v3/ui/analog_out_v3.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_AnalogOutV3(object):
    def setupUi(self, AnalogOutV3):
        AnalogOutV3.setObjectName("AnalogOutV3")
        AnalogOutV3.resize(718, 494)
        self.verticalLayout = QtWidgets.QVBoxLayout(AnalogOutV3)
        self.verticalLayout.setObjectName("verticalLayout")
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.input_voltage_desc_label = QtWidgets.QLabel(AnalogOutV3)
        self.input_voltage_desc_label.setObjectName("input_voltage_desc_label")
        self.gridLayout.addWidget(self.input_voltage_desc_label, 0, 0, 1, 1)
        self.output_voltage_label = QtWidgets.QLabel(AnalogOutV3)
        self.output_voltage_label.setObjectName("output_voltage_label")
        self.gridLayout.addWidget(self.output_voltage_label, 1, 0, 1, 1)
        self.input_voltage_label = QtWidgets.QLabel(AnalogOutV3)
        self.input_voltage_label.setObjectName("input_voltage_label")
        self.gridLayout.addWidget(self.input_voltage_label, 0, 1, 1, 1)
        self.output_voltage_box = QtWidgets.QDoubleSpinBox(AnalogOutV3)
        self.output_voltage_box.setDecimals(3)
        self.output_voltage_box.setMaximum(12.0)
        self.output_voltage_box.setSingleStep(0.1)
        self.output_voltage_box.setObjectName("output_voltage_box")
        self.gridLayout.addWidget(self.output_voltage_box, 1, 1, 1, 1)
        self.horizontalLayout.addLayout(self.gridLayout)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.verticalLayout.addLayout(self.horizontalLayout)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)

        self.retranslateUi(AnalogOutV3)
        QtCore.QMetaObject.connectSlotsByName(AnalogOutV3)

    def retranslateUi(self, AnalogOutV3):
        _translate = QtCore.QCoreApplication.translate
        AnalogOutV3.setWindowTitle(_translate("AnalogOutV3", "Form"))
        self.input_voltage_desc_label.setText(_translate("AnalogOutV3", "Input Voltage:"))
        self.output_voltage_label.setText(_translate("AnalogOutV3", "Output Voltage:"))
        self.input_voltage_label.setText(_translate("AnalogOutV3", "TBD V"))
        self.output_voltage_box.setSuffix(_translate("AnalogOutV3", " V"))

