# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/dmx/ui/dmx.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_DMX(object):
    def setupUi(self, DMX):
        DMX.setObjectName("DMX")
        DMX.resize(773, 753)
        self.verticalLayout = QtWidgets.QVBoxLayout(DMX)
        self.verticalLayout.setObjectName("verticalLayout")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_3 = QtWidgets.QLabel(DMX)
        self.label_3.setObjectName("label_3")
        self.horizontalLayout.addWidget(self.label_3)
        self.mode_combobox = QtWidgets.QComboBox(DMX)
        self.mode_combobox.setObjectName("mode_combobox")
        self.mode_combobox.addItem("")
        self.mode_combobox.addItem("")
        self.horizontalLayout.addWidget(self.mode_combobox)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.frame_duration_label = QtWidgets.QLabel(DMX)
        self.frame_duration_label.setObjectName("frame_duration_label")
        self.horizontalLayout.addWidget(self.frame_duration_label)
        self.frame_duration_spinbox = QtWidgets.QSpinBox(DMX)
        self.frame_duration_spinbox.setMaximum(1000)
        self.frame_duration_spinbox.setProperty("value", 100)
        self.frame_duration_spinbox.setObjectName("frame_duration_spinbox")
        self.horizontalLayout.addWidget(self.frame_duration_spinbox)
        self.frame_duration_unit = QtWidgets.QLabel(DMX)
        self.frame_duration_unit.setObjectName("frame_duration_unit")
        self.horizontalLayout.addWidget(self.frame_duration_unit)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.address_table = QtWidgets.QTableWidget(DMX)
        self.address_table.setRowCount(512)
        self.address_table.setColumnCount(2)
        self.address_table.setObjectName("address_table")
        item = QtWidgets.QTableWidgetItem()
        self.address_table.setVerticalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.address_table.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.address_table.setHorizontalHeaderItem(1, item)
        self.verticalLayout_2.addWidget(self.address_table)
        self.layout_dmx_overview = QtWidgets.QHBoxLayout()
        self.layout_dmx_overview.setObjectName("layout_dmx_overview")
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.layout_dmx_overview.addItem(spacerItem1)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.layout_dmx_overview.addItem(spacerItem2)
        self.verticalLayout_2.addLayout(self.layout_dmx_overview)
        self.verticalLayout.addLayout(self.verticalLayout_2)

        self.retranslateUi(DMX)
        QtCore.QMetaObject.connectSlotsByName(DMX)

    def retranslateUi(self, DMX):
        _translate = QtCore.QCoreApplication.translate
        DMX.setWindowTitle(_translate("DMX", "Form"))
        self.label_3.setText(_translate("DMX", "DMX Mode:"))
        self.mode_combobox.setItemText(0, _translate("DMX", "Master"))
        self.mode_combobox.setItemText(1, _translate("DMX", "Slave"))
        self.frame_duration_label.setText(_translate("DMX", "Frame Duration:"))
        self.frame_duration_unit.setText(_translate("DMX", "ms"))
        item = self.address_table.verticalHeaderItem(0)
        item.setText(_translate("DMX", "1"))
        item = self.address_table.horizontalHeaderItem(0)
        item.setText(_translate("DMX", "Value"))
        item = self.address_table.horizontalHeaderItem(1)
        item.setText(_translate("DMX", "Slider"))

