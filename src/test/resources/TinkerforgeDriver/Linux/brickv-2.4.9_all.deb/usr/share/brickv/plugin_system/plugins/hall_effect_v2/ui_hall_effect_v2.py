# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/hall_effect_v2/ui/hall_effect_v2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_HallEffectV2(object):
    def setupUi(self, HallEffectV2):
        HallEffectV2.setObjectName("HallEffectV2")
        HallEffectV2.resize(777, 93)
        self.verticalLayout_6 = QtWidgets.QVBoxLayout(HallEffectV2)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.main_vert_layout = QtWidgets.QVBoxLayout()
        self.main_vert_layout.setObjectName("main_vert_layout")
        self.line = QtWidgets.QFrame(HallEffectV2)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.main_vert_layout.addWidget(self.line)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.label_5 = QtWidgets.QLabel(HallEffectV2)
        self.label_5.setObjectName("label_5")
        self.gridLayout.addWidget(self.label_5, 4, 7, 1, 1)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 4, 3, 1, 1)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem1, 4, 9, 1, 1)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem2, 4, 6, 1, 1)
        self.label_count = QtWidgets.QLabel(HallEffectV2)
        self.label_count.setObjectName("label_count")
        self.gridLayout.addWidget(self.label_count, 1, 2, 1, 1)
        self.button_reset = QtWidgets.QPushButton(HallEffectV2)
        self.button_reset.setObjectName("button_reset")
        self.gridLayout.addWidget(self.button_reset, 1, 7, 1, 2)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem3, 4, 0, 1, 1)
        self.spinbox_debounce = QtWidgets.QSpinBox(HallEffectV2)
        self.spinbox_debounce.setMinimum(100)
        self.spinbox_debounce.setMaximum(1000000)
        self.spinbox_debounce.setObjectName("spinbox_debounce")
        self.gridLayout.addWidget(self.spinbox_debounce, 4, 8, 1, 1)
        self.label = QtWidgets.QLabel(HallEffectV2)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 1, 1, 1, 1)
        self.spinbox_high = QtWidgets.QSpinBox(HallEffectV2)
        self.spinbox_high.setPrefix("")
        self.spinbox_high.setMinimum(-10000)
        self.spinbox_high.setMaximum(10000)
        self.spinbox_high.setObjectName("spinbox_high")
        self.gridLayout.addWidget(self.spinbox_high, 4, 5, 1, 1)
        self.spinbox_low = QtWidgets.QSpinBox(HallEffectV2)
        self.spinbox_low.setMinimum(-10000)
        self.spinbox_low.setMaximum(10000)
        self.spinbox_low.setObjectName("spinbox_low")
        self.gridLayout.addWidget(self.spinbox_low, 4, 2, 1, 1)
        self.label_4 = QtWidgets.QLabel(HallEffectV2)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 4, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(HallEffectV2)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 4, 4, 1, 1)
        self.main_vert_layout.addLayout(self.gridLayout)
        self.verticalLayout_6.addLayout(self.main_vert_layout)

        self.retranslateUi(HallEffectV2)
        QtCore.QMetaObject.connectSlotsByName(HallEffectV2)

    def retranslateUi(self, HallEffectV2):
        _translate = QtCore.QCoreApplication.translate
        HallEffectV2.setWindowTitle(_translate("HallEffectV2", "Form"))
        self.label_5.setText(_translate("HallEffectV2", "Debounce:"))
        self.label_count.setText(_translate("HallEffectV2", "0"))
        self.button_reset.setText(_translate("HallEffectV2", "Reset Counter"))
        self.spinbox_debounce.setSuffix(_translate("HallEffectV2", " µs"))
        self.label.setText(_translate("HallEffectV2", "Counter: "))
        self.spinbox_high.setSuffix(_translate("HallEffectV2", " µT"))
        self.spinbox_low.setSuffix(_translate("HallEffectV2", " µT"))
        self.label_4.setText(_translate("HallEffectV2", "Low Threshold:"))
        self.label_3.setText(_translate("HallEffectV2", "High Threshold:"))

