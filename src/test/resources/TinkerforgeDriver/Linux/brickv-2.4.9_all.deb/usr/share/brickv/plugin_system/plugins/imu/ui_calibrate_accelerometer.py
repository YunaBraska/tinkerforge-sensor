# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/imu/ui/calibrate_accelerometer.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_calibrate_accelerometer(object):
    def setupUi(self, calibrate_accelerometer):
        calibrate_accelerometer.setObjectName("calibrate_accelerometer")
        calibrate_accelerometer.resize(329, 260)
        self.verticalLayout = QtWidgets.QVBoxLayout(calibrate_accelerometer)
        self.verticalLayout.setObjectName("verticalLayout")
        self.vlayout = QtWidgets.QVBoxLayout()
        self.vlayout.setObjectName("vlayout")
        self.grid_layout = QtWidgets.QGridLayout()
        self.grid_layout.setObjectName("grid_layout")
        self.label = QtWidgets.QLabel(calibrate_accelerometer)
        self.label.setObjectName("label")
        self.grid_layout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtWidgets.QLabel(calibrate_accelerometer)
        self.label_2.setObjectName("label_2")
        self.grid_layout.addWidget(self.label_2, 0, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(calibrate_accelerometer)
        self.label_3.setObjectName("label_3")
        self.grid_layout.addWidget(self.label_3, 0, 2, 1, 1)
        self.label_4 = QtWidgets.QLabel(calibrate_accelerometer)
        self.label_4.setObjectName("label_4")
        self.grid_layout.addWidget(self.label_4, 0, 3, 1, 1)
        self.label_5 = QtWidgets.QLabel(calibrate_accelerometer)
        self.label_5.setObjectName("label_5")
        self.grid_layout.addWidget(self.label_5, 1, 0, 1, 1)
        self.label_6 = QtWidgets.QLabel(calibrate_accelerometer)
        self.label_6.setObjectName("label_6")
        self.grid_layout.addWidget(self.label_6, 2, 0, 1, 1)
        self.gain_x = QtWidgets.QLabel(calibrate_accelerometer)
        self.gain_x.setObjectName("gain_x")
        self.grid_layout.addWidget(self.gain_x, 1, 1, 1, 1)
        self.bias_x = QtWidgets.QLabel(calibrate_accelerometer)
        self.bias_x.setObjectName("bias_x")
        self.grid_layout.addWidget(self.bias_x, 2, 1, 1, 1)
        self.gain_y = QtWidgets.QLabel(calibrate_accelerometer)
        self.gain_y.setObjectName("gain_y")
        self.grid_layout.addWidget(self.gain_y, 1, 2, 1, 1)
        self.bias_y = QtWidgets.QLabel(calibrate_accelerometer)
        self.bias_y.setObjectName("bias_y")
        self.grid_layout.addWidget(self.bias_y, 2, 2, 1, 1)
        self.gain_z = QtWidgets.QLabel(calibrate_accelerometer)
        self.gain_z.setObjectName("gain_z")
        self.grid_layout.addWidget(self.gain_z, 1, 3, 1, 1)
        self.bias_z = QtWidgets.QLabel(calibrate_accelerometer)
        self.bias_z.setObjectName("bias_z")
        self.grid_layout.addWidget(self.bias_z, 2, 3, 1, 1)
        self.vlayout.addLayout(self.grid_layout)
        self.start_button = QtWidgets.QPushButton(calibrate_accelerometer)
        self.start_button.setObjectName("start_button")
        self.vlayout.addWidget(self.start_button)
        self.text_label = QtWidgets.QLabel(calibrate_accelerometer)
        self.text_label.setWordWrap(True)
        self.text_label.setObjectName("text_label")
        self.vlayout.addWidget(self.text_label)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.vlayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.vlayout)

        self.retranslateUi(calibrate_accelerometer)
        QtCore.QMetaObject.connectSlotsByName(calibrate_accelerometer)

    def retranslateUi(self, calibrate_accelerometer):
        _translate = QtCore.QCoreApplication.translate
        calibrate_accelerometer.setWindowTitle(_translate("calibrate_accelerometer", "Form"))
        self.label.setText(_translate("calibrate_accelerometer", "Type"))
        self.label_2.setText(_translate("calibrate_accelerometer", "X"))
        self.label_3.setText(_translate("calibrate_accelerometer", "Y"))
        self.label_4.setText(_translate("calibrate_accelerometer", "Z"))
        self.label_5.setText(_translate("calibrate_accelerometer", "Gain"))
        self.label_6.setText(_translate("calibrate_accelerometer", "Bias"))
        self.gain_x.setText(_translate("calibrate_accelerometer", "?"))
        self.bias_x.setText(_translate("calibrate_accelerometer", "?"))
        self.gain_y.setText(_translate("calibrate_accelerometer", "?"))
        self.bias_y.setText(_translate("calibrate_accelerometer", "?"))
        self.gain_z.setText(_translate("calibrate_accelerometer", "?"))
        self.bias_z.setText(_translate("calibrate_accelerometer", "?"))
        self.start_button.setText(_translate("calibrate_accelerometer", "Start Calibration"))
        self.text_label.setText(_translate("calibrate_accelerometer", "Text"))

