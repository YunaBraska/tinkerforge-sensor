# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/imu/ui/calibrate_import_export.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_calibrate_import_export(object):
    def setupUi(self, calibrate_import_export):
        calibrate_import_export.setObjectName("calibrate_import_export")
        calibrate_import_export.resize(329, 139)
        self.verticalLayout = QtWidgets.QVBoxLayout(calibrate_import_export)
        self.verticalLayout.setObjectName("verticalLayout")
        self.restore_button = QtWidgets.QPushButton(calibrate_import_export)
        self.restore_button.setObjectName("restore_button")
        self.verticalLayout.addWidget(self.restore_button)
        self.line = QtWidgets.QFrame(calibrate_import_export)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout.addWidget(self.line)
        self.vlayout = QtWidgets.QVBoxLayout()
        self.vlayout.setObjectName("vlayout")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.export_button = QtWidgets.QPushButton(calibrate_import_export)
        self.export_button.setEnabled(True)
        self.export_button.setFlat(False)
        self.export_button.setObjectName("export_button")
        self.horizontalLayout_2.addWidget(self.export_button)
        self.import_button = QtWidgets.QPushButton(calibrate_import_export)
        self.import_button.setObjectName("import_button")
        self.horizontalLayout_2.addWidget(self.import_button)
        self.vlayout.addLayout(self.horizontalLayout_2)
        self.verticalLayout.addLayout(self.vlayout)
        self.text_edit = QtWidgets.QPlainTextEdit(calibrate_import_export)
        self.text_edit.setObjectName("text_edit")
        self.verticalLayout.addWidget(self.text_edit)

        self.retranslateUi(calibrate_import_export)
        QtCore.QMetaObject.connectSlotsByName(calibrate_import_export)

    def retranslateUi(self, calibrate_import_export):
        _translate = QtCore.QCoreApplication.translate
        calibrate_import_export.setWindowTitle(_translate("calibrate_import_export", "Form"))
        self.restore_button.setText(_translate("calibrate_import_export", "Restore Factory Calibration"))
        self.export_button.setText(_translate("calibrate_import_export", "Export"))
        self.import_button.setText(_translate("calibrate_import_export", "Import"))

