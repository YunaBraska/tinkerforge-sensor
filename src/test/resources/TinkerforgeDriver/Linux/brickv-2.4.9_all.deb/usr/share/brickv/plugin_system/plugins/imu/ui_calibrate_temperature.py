# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/matthias/tf/dev/brickv/src/brickv/plugin_system/plugins/imu/ui/calibrate_temperature.ui'
#
# Created by: PyQt5 UI code generator 5.7
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_calibrate_temperature(object):
    def setupUi(self, calibrate_temperature):
        calibrate_temperature.setObjectName("calibrate_temperature")
        calibrate_temperature.resize(329, 260)
        self.verticalLayout = QtWidgets.QVBoxLayout(calibrate_temperature)
        self.verticalLayout.setObjectName("verticalLayout")
        self.vlayout = QtWidgets.QVBoxLayout()
        self.vlayout.setObjectName("vlayout")
        self.start_button = QtWidgets.QPushButton(calibrate_temperature)
        self.start_button.setEnabled(False)
        self.start_button.setFlat(False)
        self.start_button.setObjectName("start_button")
        self.vlayout.addWidget(self.start_button)
        self.text_label = QtWidgets.QLabel(calibrate_temperature)
        self.text_label.setAlignment(QtCore.Qt.AlignCenter)
        self.text_label.setWordWrap(True)
        self.text_label.setObjectName("text_label")
        self.vlayout.addWidget(self.text_label)
        self.verticalLayout.addLayout(self.vlayout)

        self.retranslateUi(calibrate_temperature)
        QtCore.QMetaObject.connectSlotsByName(calibrate_temperature)

    def retranslateUi(self, calibrate_temperature):
        _translate = QtCore.QCoreApplication.translate
        calibrate_temperature.setWindowTitle(_translate("calibrate_temperature", "Form"))
        self.start_button.setText(_translate("calibrate_temperature", "Start Calibration"))
        self.text_label.setText(_translate("calibrate_temperature", "Not implemented yet. Comming soon!"))

