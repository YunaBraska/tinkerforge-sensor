# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/imu_v2/ui/calibration.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Calibration(object):
    def setupUi(self, Calibration):
        Calibration.setObjectName("Calibration")
        Calibration.resize(454, 523)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(Calibration)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.grid = QtWidgets.QGridLayout()
        self.grid.setObjectName("grid")
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem, 3, 2, 1, 1)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem1, 5, 2, 1, 1)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem2, 3, 0, 1, 1)
        self.label_8 = QtWidgets.QLabel(Calibration)
        self.label_8.setObjectName("label_8")
        self.grid.addWidget(self.label_8, 3, 1, 1, 1)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem3, 2, 0, 1, 1)
        spacerItem4 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem4, 5, 0, 1, 1)
        spacerItem5 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem5, 4, 2, 1, 1)
        spacerItem6 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem6, 2, 2, 1, 1)
        self.label_9 = QtWidgets.QLabel(Calibration)
        self.label_9.setObjectName("label_9")
        self.grid.addWidget(self.label_9, 2, 1, 1, 1)
        self.label_11 = QtWidgets.QLabel(Calibration)
        self.label_11.setObjectName("label_11")
        self.grid.addWidget(self.label_11, 4, 1, 1, 1)
        self.label_12 = QtWidgets.QLabel(Calibration)
        self.label_12.setObjectName("label_12")
        self.grid.addWidget(self.label_12, 5, 1, 1, 1)
        spacerItem7 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.grid.addItem(spacerItem7, 4, 0, 1, 1)
        self.save_calibration = QtWidgets.QPushButton(Calibration)
        self.save_calibration.setEnabled(False)
        self.save_calibration.setObjectName("save_calibration")
        self.grid.addWidget(self.save_calibration, 7, 0, 1, 3)
        self.line = QtWidgets.QFrame(Calibration)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.grid.addWidget(self.line, 6, 0, 1, 3)
        self.line_2 = QtWidgets.QFrame(Calibration)
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.grid.addWidget(self.line_2, 1, 0, 1, 3)
        self.text_browser = QtWidgets.QTextBrowser(Calibration)
        self.text_browser.setObjectName("text_browser")
        self.grid.addWidget(self.text_browser, 0, 0, 1, 3)
        self.verticalLayout_2.addLayout(self.grid)

        self.retranslateUi(Calibration)
        QtCore.QMetaObject.connectSlotsByName(Calibration)

    def retranslateUi(self, Calibration):
        _translate = QtCore.QCoreApplication.translate
        Calibration.setWindowTitle(_translate("Calibration", "IMU Calibration"))
        self.label_8.setText(_translate("Calibration", "Magnetometer"))
        self.label_9.setText(_translate("Calibration", "Accelerometer"))
        self.label_11.setText(_translate("Calibration", "Gyroscope"))
        self.label_12.setText(_translate("Calibration", "System"))
        self.save_calibration.setText(_translate("Calibration", "Save Calibration"))
        self.text_browser.setHtml(_translate("Calibration", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Ubuntu\'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p></body></html>"))

