# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/isolator/ui/isolator.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Isolator(object):
    def setupUi(self, Isolator):
        Isolator.setObjectName("Isolator")
        Isolator.resize(668, 537)
        self.verticalLayout = QtWidgets.QVBoxLayout(Isolator)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout_5 = QtWidgets.QGridLayout()
        self.gridLayout_5.setObjectName("gridLayout_5")
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout_5.addItem(spacerItem, 2, 4, 1, 1)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout_5.addItem(spacerItem1, 0, 1, 1, 1)
        self.label = QtWidgets.QLabel(Isolator)
        self.label.setObjectName("label")
        self.gridLayout_5.addWidget(self.label, 1, 1, 1, 1)
        self.label_messages_from_brick = QtWidgets.QLabel(Isolator)
        self.label_messages_from_brick.setObjectName("label_messages_from_brick")
        self.gridLayout_5.addWidget(self.label_messages_from_brick, 1, 2, 1, 2)
        self.label_2 = QtWidgets.QLabel(Isolator)
        self.label_2.setObjectName("label_2")
        self.gridLayout_5.addWidget(self.label_2, 2, 1, 1, 1)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout_5.addItem(spacerItem2, 2, 0, 1, 1)
        self.label_isolated_bricklet = QtWidgets.QLabel(Isolator)
        self.label_isolated_bricklet.setObjectName("label_isolated_bricklet")
        self.gridLayout_5.addWidget(self.label_isolated_bricklet, 3, 2, 1, 1)
        self.label_messages_from_bricklet = QtWidgets.QLabel(Isolator)
        self.label_messages_from_bricklet.setObjectName("label_messages_from_bricklet")
        self.gridLayout_5.addWidget(self.label_messages_from_bricklet, 2, 2, 1, 2)
        self.label_3 = QtWidgets.QLabel(Isolator)
        self.label_3.setObjectName("label_3")
        self.gridLayout_5.addWidget(self.label_3, 3, 1, 1, 1)
        self.button_bricklet = QtWidgets.QPushButton(Isolator)
        self.button_bricklet.setObjectName("button_bricklet")
        self.gridLayout_5.addWidget(self.button_bricklet, 4, 1, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout_5)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)

        self.retranslateUi(Isolator)
        QtCore.QMetaObject.connectSlotsByName(Isolator)

    def retranslateUi(self, Isolator):
        _translate = QtCore.QCoreApplication.translate
        Isolator.setWindowTitle(_translate("Isolator", "Form"))
        self.label.setText(_translate("Isolator", "Messages from Brick to Bricklet:"))
        self.label_messages_from_brick.setText(_translate("Isolator", "TBD"))
        self.label_2.setText(_translate("Isolator", "Messages from Bricklet to Brick:"))
        self.label_isolated_bricklet.setText(_translate("Isolator", "TBD"))
        self.label_messages_from_bricklet.setText(_translate("Isolator", "TBD"))
        self.label_3.setText(_translate("Isolator", "Isolated Bricklet:"))
        self.button_bricklet.setText(_translate("Isolator", "Open Bricklet"))

