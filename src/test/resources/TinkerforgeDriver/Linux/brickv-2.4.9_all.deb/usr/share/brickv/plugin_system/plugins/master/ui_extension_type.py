# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/master/ui/extension_type.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_ExtensionType(object):
    def setupUi(self, ExtensionType):
        ExtensionType.setObjectName("ExtensionType")
        ExtensionType.resize(280, 78)
        self.gridLayout = QtWidgets.QGridLayout(ExtensionType)
        self.gridLayout.setObjectName("gridLayout")
        self.label_2 = QtWidgets.QLabel(ExtensionType)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.combo_extension = QtWidgets.QComboBox(ExtensionType)
        self.combo_extension.setObjectName("combo_extension")
        self.combo_extension.addItem("")
        self.combo_extension.addItem("")
        self.gridLayout.addWidget(self.combo_extension, 0, 1, 1, 2)
        self.label_9 = QtWidgets.QLabel(ExtensionType)
        self.label_9.setObjectName("label_9")
        self.gridLayout.addWidget(self.label_9, 1, 0, 1, 1)
        self.type_box = QtWidgets.QComboBox(ExtensionType)
        self.type_box.setObjectName("type_box")
        self.type_box.addItem("")
        self.type_box.addItem("")
        self.type_box.addItem("")
        self.type_box.addItem("")
        self.type_box.addItem("")
        self.type_box.addItem("")
        self.gridLayout.addWidget(self.type_box, 1, 1, 1, 1)
        self.button_type_save = QtWidgets.QPushButton(ExtensionType)
        self.button_type_save.setObjectName("button_type_save")
        self.gridLayout.addWidget(self.button_type_save, 1, 2, 1, 1)

        self.retranslateUi(ExtensionType)
        QtCore.QMetaObject.connectSlotsByName(ExtensionType)

    def retranslateUi(self, ExtensionType):
        _translate = QtCore.QCoreApplication.translate
        ExtensionType.setWindowTitle(_translate("ExtensionType", "Configure Extension Type"))
        self.label_2.setText(_translate("ExtensionType", "Extension:"))
        self.combo_extension.setItemText(0, _translate("ExtensionType", "0"))
        self.combo_extension.setItemText(1, _translate("ExtensionType", "1"))
        self.label_9.setText(_translate("ExtensionType", "Type:"))
        self.type_box.setItemText(0, _translate("ExtensionType", "None"))
        self.type_box.setItemText(1, _translate("ExtensionType", "Chibi"))
        self.type_box.setItemText(2, _translate("ExtensionType", "RS485"))
        self.type_box.setItemText(3, _translate("ExtensionType", "WIFI"))
        self.type_box.setItemText(4, _translate("ExtensionType", "Ethernet"))
        self.type_box.setItemText(5, _translate("ExtensionType", "WIFI 2.0"))
        self.button_type_save.setText(_translate("ExtensionType", "Save"))

