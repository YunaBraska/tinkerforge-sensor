# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/master/ui/master.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Master(object):
    def setupUi(self, Master):
        Master.setObjectName("Master")
        Master.resize(796, 519)
        self.verticalLayout = QtWidgets.QVBoxLayout(Master)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_5 = QtWidgets.QLabel(Master)
        self.label_5.setObjectName("label_5")
        self.horizontalLayout.addWidget(self.label_5)
        self.stack_voltage_label = QtWidgets.QLabel(Master)
        self.stack_voltage_label.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.stack_voltage_label.setObjectName("stack_voltage_label")
        self.horizontalLayout.addWidget(self.stack_voltage_label)
        spacerItem = QtWidgets.QSpacerItem(20, 1, QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.label_3 = QtWidgets.QLabel(Master)
        self.label_3.setObjectName("label_3")
        self.horizontalLayout.addWidget(self.label_3)
        self.stack_current_label = QtWidgets.QLabel(Master)
        self.stack_current_label.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.stack_current_label.setObjectName("stack_current_label")
        self.horizontalLayout.addWidget(self.stack_current_label)
        spacerItem1 = QtWidgets.QSpacerItem(1, 1, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.label_2 = QtWidgets.QLabel(Master)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout.addWidget(self.label_2)
        self.extension_label = QtWidgets.QLabel(Master)
        self.extension_label.setObjectName("extension_label")
        self.horizontalLayout.addWidget(self.extension_label)
        self.extension_type_button = QtWidgets.QPushButton(Master)
        self.extension_type_button.setObjectName("extension_type_button")
        self.horizontalLayout.addWidget(self.extension_type_button)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.label_no_extension = QtWidgets.QLabel(Master)
        self.label_no_extension.setAlignment(QtCore.Qt.AlignCenter)
        self.label_no_extension.setObjectName("label_no_extension")
        self.verticalLayout.addWidget(self.label_no_extension)
        self.tab_widget = QtWidgets.QTabWidget(Master)
        self.tab_widget.setTabPosition(QtWidgets.QTabWidget.West)
        self.tab_widget.setObjectName("tab_widget")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")
        self.tab_widget.addTab(self.tab, "")
        self.verticalLayout.addWidget(self.tab_widget)

        self.retranslateUi(Master)
        self.tab_widget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Master)

    def retranslateUi(self, Master):
        _translate = QtCore.QCoreApplication.translate
        Master.setWindowTitle(_translate("Master", "Form"))
        self.label_5.setText(_translate("Master", "Stack Voltage:"))
        self.stack_voltage_label.setText(_translate("Master", "0 V"))
        self.label_3.setText(_translate("Master", "Stack Current:"))
        self.stack_current_label.setText(_translate("Master", "0 mA"))
        self.label_2.setText(_translate("Master", "Extensions:"))
        self.extension_label.setText(_translate("Master", "None Present"))
        self.extension_type_button.setText(_translate("Master", "Configure"))
        self.label_no_extension.setText(_translate("Master", "Could not find any Master Extensions on Master Brick stack."))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab), _translate("Master", "dummy"))

