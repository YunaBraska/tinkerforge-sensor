# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'brickv/plugin_system/plugins/one_wire/ui/one_wire.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_OneWire(object):
    def setupUi(self, OneWire):
        OneWire.setObjectName("OneWire")
        OneWire.resize(762, 437)
        self.verticalLayout = QtWidgets.QVBoxLayout(OneWire)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtWidgets.QLabel(OneWire)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 5, 0, 1, 1)
        self.button_search = QtWidgets.QPushButton(OneWire)
        self.button_search.setObjectName("button_search")
        self.gridLayout.addWidget(self.button_search, 1, 0, 1, 4)
        self.button_reset = QtWidgets.QPushButton(OneWire)
        self.button_reset.setObjectName("button_reset")
        self.gridLayout.addWidget(self.button_reset, 0, 0, 1, 4)
        self.button_read_byte = QtWidgets.QPushButton(OneWire)
        self.button_read_byte.setObjectName("button_read_byte")
        self.gridLayout.addWidget(self.button_read_byte, 4, 0, 1, 4)
        self.label_2 = QtWidgets.QLabel(OneWire)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 6, 0, 1, 1)
        self.spinbox_write_command = SpinBoxHex(OneWire)
        self.spinbox_write_command.setMaximum(255)
        self.spinbox_write_command.setObjectName("spinbox_write_command")
        self.gridLayout.addWidget(self.spinbox_write_command, 5, 2, 1, 1)
        self.combo_box_write_command = QtWidgets.QComboBox(OneWire)
        self.combo_box_write_command.setObjectName("combo_box_write_command")
        self.combo_box_write_command.addItem("")
        self.gridLayout.addWidget(self.combo_box_write_command, 5, 1, 1, 1)
        self.button_write_byte = QtWidgets.QPushButton(OneWire)
        self.button_write_byte.setObjectName("button_write_byte")
        self.gridLayout.addWidget(self.button_write_byte, 6, 3, 1, 1)
        self.button_write_command = QtWidgets.QPushButton(OneWire)
        self.button_write_command.setObjectName("button_write_command")
        self.gridLayout.addWidget(self.button_write_command, 5, 3, 1, 1)
        self.spinbox_write_byte = SpinBoxHex(OneWire)
        self.spinbox_write_byte.setMaximum(255)
        self.spinbox_write_byte.setObjectName("spinbox_write_byte")
        self.gridLayout.addWidget(self.spinbox_write_byte, 6, 1, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout)
        self.tree_widget = QtWidgets.QTreeWidget(OneWire)
        self.tree_widget.setObjectName("tree_widget")
        self.verticalLayout.addWidget(self.tree_widget)

        self.retranslateUi(OneWire)
        QtCore.QMetaObject.connectSlotsByName(OneWire)

    def retranslateUi(self, OneWire):
        _translate = QtCore.QCoreApplication.translate
        OneWire.setWindowTitle(_translate("OneWire", "Form"))
        self.label.setText(_translate("OneWire", "Write Comand:"))
        self.button_search.setText(_translate("OneWire", "Search Bus"))
        self.button_reset.setText(_translate("OneWire", "Reset Bus"))
        self.button_read_byte.setText(_translate("OneWire", "Read Byte"))
        self.label_2.setText(_translate("OneWire", "Write Byte:"))
        self.combo_box_write_command.setItemText(0, _translate("OneWire", "Skip ID"))
        self.button_write_byte.setText(_translate("OneWire", "Write"))
        self.button_write_command.setText(_translate("OneWire", "Write"))
        self.tree_widget.headerItem().setText(0, _translate("OneWire", "Time"))
        self.tree_widget.headerItem().setText(1, _translate("OneWire", "Command"))
        self.tree_widget.headerItem().setText(2, _translate("OneWire", "Value"))
        self.tree_widget.headerItem().setText(3, _translate("OneWire", "Status"))

from brickv.spin_box_hex import SpinBoxHex
